from django.views import View
from django.shortcuts import redirect
from store.models.product import Product
from store.models.order import Order
from store.models.customer import Customer


class CheckOut(View):
    def post(self, request):
        address = request.POST.get('address')
        phone = request.POST.get('phone')
        customer = request.session.get('customer_id')
        cart = request.session.get('cart')
        products = Product.get_prods_by_id(list(cart.keys()))

        for product in products:
            order = Order(customer=Customer(id=customer), # You can do it this way too, if you don't have instance avaliable
                          product=product, # Here we cannot pass id we have to pass product instance
                          price=product.price,
                          quantity=cart.get(str(product.id)),
                          phone=phone,
                          address=address)
            order.save()
        request.session['cart'] = {}
        return redirect('cart')
