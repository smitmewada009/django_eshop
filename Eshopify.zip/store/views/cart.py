from django.views import View
from django.shortcuts import render
from store.models.product import Product


class Cart(View):
    def get(self, request):
            cart = {}
            if not request.session.get('cart'):
                request.session['cart'] = cart
            keys = list(request.session.get('cart').keys())
            products = Product.get_prods_by_id(keys)
            print(products)
            return render(request, 'cart.html', {'products': products})



