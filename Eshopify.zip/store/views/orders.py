from django.shortcuts import render, redirect
from django.views import View
from store.models.order import Order
from store.middlewares.auth import auth_middleware
from django.utils.decorators import method_decorator
# You have to use above imported decorator on mehthods

class OrdersView(View):
    # @method_decorator(auth_middleware) # You can use middleware like this on functions but not on methods
    def get(self, request):
        customer = request.session.get('customer_id')
        orders = Order.get_orders_by_customer(customer)
        return render(request, 'orders.html', {'orders': orders})