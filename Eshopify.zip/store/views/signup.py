from django.shortcuts import redirect, render
from store.models import Customer
from django.contrib.auth.hashers import make_password
from django.views import View


class SignUp(View):
    def get(self, request):
        return render(request, 'signup.html')

    def validate_customers(self, first_name, customer):
        error_message = None
        if not first_name:
            error_message = "Firstname required!"
        elif len(first_name) < 4:
            error_message = "Firstname must be 4 characters long"

        if not error_message:
            customer.password = make_password(customer.password)
            customer.register_customer()
        else:
            return error_message

    def post(self, request):
        post_data = request.POST
        first_name = post_data.get('firstname')
        last_name = post_data.get('lastname')
        phone = post_data.get('phone')
        email = post_data.get('email')
        password = post_data.get('password')

        values = {
            'firstname': first_name,
            'lastname': last_name,
            'phone': phone,
            'email': email
        }

        customer = Customer(first_name=first_name,
                            last_name=last_name,
                            phone=phone,
                            email=email,
                            password=password
                            )
        data = {
            'values': values,
            'error': self.validate_customers(first_name, customer)
        }
        if data.get('error'):
            return render(request, 'signup.html', {'data': data})
        else:
            return redirect('homepage')
