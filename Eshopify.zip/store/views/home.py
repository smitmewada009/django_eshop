from django.shortcuts import render, redirect
from store.models import Product
from store.models.category import Category
from django.views import View
from django.http import HttpResponse


# Create your views here.

class Index(View):

    def get(self, request):
        cart = request.session.get('cart')
        if not cart:
            request.session['cart'] = {}
        products = None
        categories = Category.get_all_cat()
        category_id = request.GET.get('category')  # Here use get() method instead of [] square brackets
        if category_id:
            products = Product.get_products_by_id(category_id)
        else:
            products = Product.get_all_products()

        data = {
            'products': products,
            'categories': categories
        }
        # print('you are: ', request.session.get('customer_email')) -
        return render(request, 'index.html', {'data': data})

    def post(self, request):
        product = request.POST.get('product')
        remove = request.POST.get('remove')
        cart = request.session.get('cart')
        if cart:
            qty = cart.get(product)
            if qty:
                if remove:
                    if qty <= 1:
                        cart.pop(product)
                    else:
                        cart[product] = qty - 1

                else:
                    cart[product] = qty + 1
            else:
                cart[product] = 1
        else:
            cart = {}
            cart[product] = 1
        request.session['cart'] = cart
        # print(request.session['cart'])
        return redirect('homepage')


