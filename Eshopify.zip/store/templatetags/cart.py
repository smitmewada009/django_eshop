from django import template

register = template.Library()


@register.filter(name="is_in_cart")
def is_in_cart(product, cart):
    try:
        keys = cart.keys()
        for key in keys:
            if int(key) == product.id:  # Here convert it into int
                return True
        return False
    except:
        return False


@register.filter(name="count_qty")
def count_qty(product, cart):
    keys = cart.keys()
    for key in keys:
        if int(key) == product.id:
            return cart.get(key)
    return 0


@register.filter(name='price_total')
def price_total(product, cart):
    total_price = product.price * count_qty(product, cart)
    return total_price


@register.filter(name='calculate_total')
def calculate_total(products, cart):
    total = 0
    for product in products:
        total += price_total(product, cart)
    return total
