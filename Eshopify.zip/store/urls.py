from django.urls import path
from .views import home, login, signup, cart, checkout, orders
from .middlewares.auth import auth_middleware

urlpatterns = [
    path('', home.Index.as_view(), name="homepage"),
    path('signup', signup.SignUp.as_view(), name="signup_page"),
    path('login', login.Login.as_view(), name="login_page"),
    path('logout', login.logout, name="logout_page"),
    path('cart', cart.Cart.as_view(), name="cart"),
    path('checkout', auth_middleware(checkout.CheckOut.as_view()), name="checkout"),
    path('order', auth_middleware(orders.OrdersView.as_view()), name="orders")
]
